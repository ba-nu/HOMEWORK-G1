
package travel;


public class payment extends manager {
   private double amount;
   private String datePayment;
 public double getAmount(){
       return amount;
   }
  public String getDatePaymentt(){
       return datePayment;
   }
     public void setAmount(double am){
       this.amount=am;
   } public void setDatePayment(String dp){
       this.datePayment=dp;
   }
   
 
  }




