
package travel;


public class cabs extends manager {
    private String Type;
    
     public String getType(){
       return Type;
   }
     public void setType(String t){
       this.Type=t;
   }
}
